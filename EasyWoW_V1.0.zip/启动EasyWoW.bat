@echo off
chcp 65001 >nul
echo EasyWoW v1.0 — 正在启动...
start "" "%~dp0EasyWow.Client.exe"
