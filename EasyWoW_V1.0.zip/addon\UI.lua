-- UI.lua
-- Minimal spell queue display: grip handle + icon + hotkey overlay + cooldown
local NUM_ICONS = 3
local ICON_SIZE = 42
local SPACING = 2
local GRIP_WIDTH = 12
local ICON_LEFT = GRIP_WIDTH + SPACING  -- offset from frame left edge to first icon

local icons = {}

-- Scan action bar for spell -> key text mapping (JustAC 风格)
local function ScanActionBarKeys()
    local map = {}
    local prefixes = {
        "ActionButton", "MultiBarBottomLeftButton", "MultiBarBottomRightButton",
        "MultiBarRightButton", "MultiBarLeftButton",
        "MultiBar5Button", "MultiBar6Button", "MultiBar7Button",
    }
    for _, prefix in ipairs(prefixes) do
        for i = 1, 12 do
            local btn = _G[prefix .. i]
            if btn then
                local slot = btn.action or (btn.GetAttribute and btn:GetAttribute("action"))
                if slot then
                    local actionType, id = GetActionInfo(slot)
                    if actionType == "spell" and id then
                        local hotkey = btn.HotKey
                        if hotkey then
                            local text = hotkey:GetText() or ""
                            text = text:gsub("|T.-|t", "")  -- strip textures
                            text = text:match("^%s*(.-)%s*$") or text
                            if text ~= "" then
                                map[id] = text
                            end
                        end
                    end
                end
            end
        end
    end
    return map
end

local function CreateIcon(parent, index)
    local btn = CreateFrame("Frame", nil, parent)
    btn:SetSize(ICON_SIZE, ICON_SIZE)
    if index == 1 then
        btn:SetPoint("LEFT", parent, "LEFT", ICON_LEFT, 0)
    else
        btn:SetPoint("LEFT", icons[index - 1], "RIGHT", SPACING, 0)
    end

    -- Background
    local bg = btn:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(btn)
    bg:SetColorTexture(0, 0, 0, 0.5)

    -- Icon texture
    local icon = btn:CreateTexture(nil, "ARTWORK")
    icon:SetAllPoints(btn)
    icons[index] = btn

    -- Cooldown
    local cd = CreateFrame("Cooldown", nil, btn, "CooldownFrameTemplate")
    cd:SetAllPoints(btn)
    cd:SetDrawSwipe(true)
    cd:SetReverse(false)
    cd:Hide()
    btn.cd = cd
    btn.icon = icon
    btn.spellID = 0

    -- Hotkey text (位置编号)
    local hotkey = btn:CreateFontString(nil, "OVERLAY")
    hotkey:SetFont(STANDARD_TEXT_FONT, 11, "OUTLINE")
    hotkey:SetTextColor(1, 1, 0.8, 1)
    hotkey:SetPoint("TOPRIGHT", btn, "TOPRIGHT", -1, -1)
    btn.hotkey = hotkey

    btn:Hide()
    return btn
end

-- Main frame
local frame = CreateFrame("Frame", "EasyWoWUI", UIParent, "BackdropTemplate")
frame:SetSize(GRIP_WIDTH + SPACING + NUM_ICONS * ICON_SIZE + (NUM_ICONS - 1) * SPACING, ICON_SIZE)

-- Default position (center) until ADDON_LOADED restores saved pos
frame:SetPoint("CENTER", UIParent, "CENTER", 0, -200)

-- Restore saved position after ADDON_LOADED (SavedVariables guaranteed ready)
local posLoader = CreateFrame("Frame")
posLoader:RegisterEvent("ADDON_LOADED")
posLoader:SetScript("OnEvent", function(_, _, arg1)
    if arg1 ~= "EasyWoW" then return end
    posLoader:UnregisterAllEvents()
    posLoader:Hide()
    if EasyWoW_UIPos then
        frame:ClearAllPoints()
        frame:SetPoint("TOPLEFT", UIParent, "TOPLEFT", EasyWoW_UIPos.left, EasyWoW_UIPos.top)
    end
end)

frame:EnableMouse(true)
frame:SetMovable(true)

-- Backdrop
frame:SetBackdrop({
    bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 8, edgeSize = 4,
    insets = { left = 1, right = 1, top = 1, bottom = 1 }
})
frame:SetBackdropColor(0, 0, 0, 0.75)

-- Grip handle (Justac-style grab tab with three dots)
local grip = CreateFrame("Button", nil, frame)
grip:SetSize(GRIP_WIDTH, ICON_SIZE)
grip:SetPoint("LEFT", frame, "LEFT", 0, 0)

-- Three-dot grip indicator
local dotSpacing = 6
for i = 1, 3 do
    local dot = grip:CreateTexture(nil, "OVERLAY")
    dot:SetSize(2, 2)
    dot:SetColorTexture(0.7, 0.7, 0.7, 0.8)
    dot:SetPoint("CENTER", grip, "CENTER", 0, (i - 2) * dotSpacing)
end

grip:EnableMouse(true)
grip:RegisterForDrag("LeftButton")
grip:SetScript("OnDragStart", function()
    frame:StartMoving(true)
end)
grip:SetScript("OnDragStop", function()
    frame:StopMovingOrSizing()
    local left, bottom = frame:GetLeft(), frame:GetBottom()
    if left and bottom then
        EasyWoW_UIPos = { left = left, top = UIParent:GetHeight() - bottom }
    end
end)
frame.grip = grip

-- EasyWoW label (drag hint)
local hint = frame:CreateFontString(nil, "OVERLAY")
hint:SetFont(STANDARD_TEXT_FONT, 9, "OUTLINE")
hint:SetTextColor(0.5, 0.5, 0.5, 0.6)
hint:SetPoint("TOPLEFT", grip, "TOPLEFT", 2, 1)
hint:SetText("EW")

for i = 1, NUM_ICONS do
    CreateIcon(frame, i)
end

-- Update on each tick
local updateFrame = CreateFrame("Frame")
local lastScan = 0
updateFrame:SetScript("OnUpdate", function()
    local now = GetTime()
    if now - lastScan > 1.0 then
        lastScan = now
        local barKeys = ScanActionBarKeys()
        -- store in upvalue for display
        updateFrame.barKeys = barKeys
    end

    local spells = EasyWoW_GetRotationSpells()
    local primary = C_AssistedCombat and C_AssistedCombat.GetNextCastSpell()
    local count = math.min(NUM_ICONS, spells and #spells or 0)

    if count == 0 then
        for i = 1, NUM_ICONS do
            icons[i]:Hide()
        end
        frame:Hide()
        return
    end

    -- Build display list: position 1 = recommended (若有), otherwise rotation[1]
    local display = {}
    if primary and primary > 0 then
        display = {primary}
        local seen = {[primary] = true}
        for _, sid in ipairs(spells or {}) do
            if not seen[sid] then
                seen[sid] = true
                display[#display + 1] = sid
            end
            if #display >= NUM_ICONS then break end
        end
    else
        -- 无推荐时直接显示前几个 rotation 技能
        for i = 1, math.min(NUM_ICONS, #spells) do
            display[i] = spells[i]
        end
    end

    for i = 1, NUM_ICONS do
        local btn = icons[i]
        local sid = display[i]
        if sid then
            local info = C_Spell and C_Spell.GetSpellInfo(sid)
            if info then
                btn.icon:SetTexture(info.iconID)
                btn.icon:Show()
            end
            -- 动作条按键（JustAC 风格，不在动作条上则不显示文字）
            local barKeys = updateFrame.barKeys or {}
            btn.hotkey:SetText(barKeys[sid] or "")
            -- Cooldown（防 taint：secret number 无法比较，用 pcall 兜底）
            local cdInfo = C_Spell and C_Spell.GetSpellCooldown(sid)
            local cdOk, hasCd = pcall(function() return cdInfo and cdInfo.duration > 0 end)
            if cdOk and hasCd then
                pcall(btn.cd.SetCooldown, btn.cd, cdInfo.startTime, cdInfo.duration)
                btn.cd:Show()
            else
                btn.cd:Hide()
            end
            btn.spellID = sid
            btn:Show()
        else
            btn:Hide()
        end
    end
    frame:Show()
end)
