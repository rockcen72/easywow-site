-- SpellCollector.lua
-- Collects rotation spells on PLAYER_SPECIALIZATION_CHANGED
local spells = {}

function EasyWoW_GetRotationSpells()
    return spells
end

local function Collect()
    if not C_AssistedCombat or not C_AssistedCombat.GetRotationSpells then
        return
    end
    local success, result = pcall(C_AssistedCombat.GetRotationSpells)
    if success and result and #result > 0 then
        spells = result
        EasyWoW_AutoBind(true)  -- 自动绑定，不弹消息

        -- Write rotation spell IDs to GP[200+] for C# client to read.
        -- Up to 60 entries, terminated by 0.
        -- Also write spell names to GP[300+], 3 doubles per name (6 bytes each, up to 18 chars).
        local idBase = 200
        local nameBase = 300
        for i = 1, 60 do
            local sid = spells[i]
            GP[idBase + i - 1] = sid or 0

            -- Pack spell name into GP[nameBase + i*3 - 3 .. nameBase + i*3 - 1]
            if sid then
                local info = C_Spell and C_Spell.GetSpellInfo(sid)
                local name = (info and info.name) or ""
                local function pbyte(idx) return string.byte(name, idx) or 0 end
                GP[nameBase + i*3 - 3] = pbyte(1) + pbyte(2)*256 + pbyte(3)*65536
                    + pbyte(4)*16777216 + pbyte(5)*4294967296 + pbyte(6)*1099511627776
                GP[nameBase + i*3 - 2] = pbyte(7) + pbyte(8)*256 + pbyte(9)*65536
                    + pbyte(10)*16777216 + pbyte(11)*4294967296 + pbyte(12)*1099511627776
                GP[nameBase + i*3 - 1] = pbyte(13) + pbyte(14)*256 + pbyte(15)*65536
                    + pbyte(16)*16777216 + pbyte(17)*4294967296 + pbyte(18)*1099511627776
            else
                GP[nameBase + i*3 - 3] = 0
            end
        end
    end
end

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_ENTERING_WORLD")
f:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
f:SetScript("OnEvent", function(_, event, arg1)
    if (event == "ADDON_LOADED" and arg1 == "EasyWoW") or event == "PLAYER_ENTERING_WORLD" then
        Collect()
    elseif event == "PLAYER_SPECIALIZATION_CHANGED" then
        EasyWoW_ResetBindings()  -- 重置绑定标记，下次 OnUpdate 重新注册
        Collect()  -- Collect() 成功会覆盖 spells，失败则保留旧值
        -- 注：不要在 Collect() 前清空 spells，否则如果 API 暂时未就绪，图标会丢失
    end
end)
