-- EasyWoW.lua
-- Creates GP[] bridge table with magic pattern for hook DLL scanning.
-- On each frame: reads recommended spell, finds position, looks up key binding,
-- writes action data to GP[25]/GP[26]/GP[27].
-- GP[] layout: 999 sequential doubles (1..999), starts with magic number (2026...).

local magic = 202600000001.0

-- Create GP[]: 999 entries, each = magic + (index - 1)
-- Lua 5.1 stores the array part as a contiguous TValue block, which the
-- hook DLL's memory scanner locates via the magic number pattern.
GP = {}
for i = 1, 999 do
    GP[i] = magic + (i - 1)
end


-- Check if a spell is currently usable (not on cooldown, enough resources).
-- Uses pcall for each check to avoid taint (secret numbers).
local function IsCastable(sid)
    local ok1, usable = pcall(C_Spell.IsSpellUsable, sid)
    if ok1 and not usable then return false end

    local ok2, cdStart, cdDuration = pcall(C_Spell.GetSpellCooldown, sid)
    if ok2 and cdStart and cdDuration and cdDuration > 0 then
        return false
    end

    return true
end

--- Check if a spell is a shapeshift toggle that would shift the player
--- out of their current form (Cat Form → caster when re-cast).
local function IsShapeshiftToggle(sid)
    if sid == 768 then
        local _, _, isActive = GetShapeshiftFormInfo(1)
        return isActive == true
    end
    return false
end

--- Check if a spell is a weapon coating (rogue poison, shaman weapon imbue).
local function IsWeaponCoating(name)
    if not name then return false end
    return name:find("毒药") or name:find("药膏") or name:find("Poison") or name:find("Imbue")
end

--- Check if a weapon coating is already active on the player's weapons.
--- Uses GetWeaponEnchantInfo() which returns main-hand and off-hand enchant state.
--- Returns true if EITHER weapon has an enchantment (avoid re-applying).
local function HasWeaponCoating()
    local hasMH, _, _, hasOH, _, _ = GetWeaponEnchantInfo()
    return hasMH or hasOH
end

-- Find the best spell to cast: prefer C_AssistedCombat (must have key binding),
-- fallback to rotation list (priority order), then action bar scan.
local function FindCastableSpell(recommended)
    -- 1. C_AssistedCombat recommendation (tracks combat state: target, resources,
    --    buffs, cooldowns). Must have a key binding in EasyWoW_CustomBindings.
    --    Skip weapon coatings if already active (prevents re-applying every tick).
    if recommended and recommended > 0 and IsCastable(recommended) and not IsShapeshiftToggle(recommended) then
        local info = C_Spell and C_Spell.GetSpellInfo(recommended)
        if info and info.name and not (IsWeaponCoating(info.name) and HasWeaponCoating()) then
            local key = EasyWoW_CustomBindings[info.name]
            if key then
                return recommended
            end
        end
    end

    -- 2. Fallback: rotation list scan (priority order). Covers situations
    --    where C_AssistedCombat returns nil or an unbound spell.
    --    Skip weapon coatings if already active.
    local spells = EasyWoW_GetRotationSpells()
    if spells then
        for _, sid in ipairs(spells) do
            if IsCastable(sid) and not IsShapeshiftToggle(sid) then
                local info = C_Spell and C_Spell.GetSpellInfo(sid)
                if info and info.name then
                    -- Skip coating if weapon already enchanted, try next spell
                    if not (IsWeaponCoating(info.name) and HasWeaponCoating()) then
                        local key = EasyWoW_CustomBindings[info.name]
                        if key then
                            return sid
                        end
                    end
                end
            end
        end
    end

    -- 3. Last resort: action bar scan for trigger/transform spells
    --    (e.g. 圣光之锤 awakening into 灰烬觉醒) that may not be in the
    --    rotation list (different spell ID from talent/spell upgrade).
    for i = 1, 60 do
        local actionType, actionId = GetActionInfo(i)
        if actionType == "spell" and actionId and actionId > 0 then
            local info = C_Spell.GetSpellInfo(actionId)
            if info and info.name and IsCastable(actionId) and not (IsWeaponCoating(info.name) and HasWeaponCoating()) then
                local key = EasyWoW_CustomBindings[info.name]
                if key then
                    return actionId
                end
            end
        end
    end

    return nil
end

-- Heartbeat counter
local heartbeat = 0

-- Main OnUpdate frame (started after ADDON_LOADED)
local updateFrame = CreateFrame("Frame")

updateFrame:SetScript("OnUpdate", function()
    -- Wrap in pcall + report errors to GP[33] for C# diagnostic.
    local ok, err = pcall(function()
        -- 1. Get recommended spell from C_AssistedCombat
        local recommended = nil
        if C_AssistedCombat and C_AssistedCombat.GetNextCastSpell then
            local ok2, result = pcall(C_AssistedCombat.GetNextCastSpell)
            if ok2 and result and type(result) == "number" and result > 0 then
                recommended = result
            end
        end

        -- 2. Find castable spell (trust C_AssistedCombat recommendation).
        --    If FindCastableSpell returns nil because the recommended spell has no
        --    binding in EasyWoW_CustomBindings, use it anyway with position=0 so
        --    C# can auto-add it to the rotation and sync a fresh key binding.
        --    But skip weapon coatings if already active (prevents re-apply loop).
        local spellID = FindCastableSpell(recommended)
        if not spellID and recommended and recommended > 0 and IsCastable(recommended) and not IsShapeshiftToggle(recommended) then
            local info = C_Spell and C_Spell.GetSpellInfo(recommended)
            if not (info and info.name and IsWeaponCoating(info.name) and HasWeaponCoating()) then
                spellID = recommended
            end
        end

        -- 3. Get spell name and find position in rotation list
        local position = 0
        local spellName = ""
        if spellID then
            local info = C_Spell and C_Spell.GetSpellInfo(spellID)
            if info and info.name then
                spellName = info.name
            end
            local spells = EasyWoW_GetRotationSpells()
            if spells then
                for i, sid in ipairs(spells) do
                    if sid == spellID then
                        position = i
                        break
                    end
                end
                -- Name-based fallback for transformed spells (e.g. 灰烬觉醒→圣光之锤)
                -- that have different IDs but the same name in the rotation list.
                if position == 0 and spellName ~= "" then
                    for i, sid in ipairs(spells) do
                        local si = C_Spell and C_Spell.GetSpellInfo(sid)
                        if si and si.name == spellName then
                            position = i
                            break
                        end
                    end
                end
            end
        end

        -- 4. Pack spell name into GP[28-30] (6 chars per double, up to 18 chars)
        local b1 = string.byte(spellName, 1) or 0
        local b2 = string.byte(spellName, 2) or 0
        local b3 = string.byte(spellName, 3) or 0
        local b4 = string.byte(spellName, 4) or 0
        local b5 = string.byte(spellName, 5) or 0
        local b6 = string.byte(spellName, 6) or 0
        GP[28] = b1 + b2*256 + b3*65536 + b4*16777216 + b5*4294967296 + b6*1099511627776

        local b7  = string.byte(spellName, 7) or 0
        local b8  = string.byte(spellName, 8) or 0
        local b9  = string.byte(spellName, 9) or 0
        local b10 = string.byte(spellName, 10) or 0
        local b11 = string.byte(spellName, 11) or 0
        local b12 = string.byte(spellName, 12) or 0
        GP[29] = b7 + b8*256 + b9*65536 + b10*16777216 + b11*4294967296 + b12*1099511627776

        local b13 = string.byte(spellName, 13) or 0
        local b14 = string.byte(spellName, 14) or 0
        local b15 = string.byte(spellName, 15) or 0
        local b16 = string.byte(spellName, 16) or 0
        local b17 = string.byte(spellName, 17) or 0
        local b18 = string.byte(spellName, 18) or 0
        GP[30] = b13 + b14*256 + b15*65536 + b16*16777216 + b17*4294967296 + b18*1099511627776

        -- 5. Process pending binding BEFORE AutoBind/Register.
        --    C# writes GP[449]=1 followed by GP[450]=slot. Processing here ensures
        --    the clear happens before new bindings are registered, so the cache file
        --    never saves the cleared state without the new bindings.
        EasyWoW_ProcessPendingBinding()

        -- 6. AutoBind + Register (runs after ProcessPendingBinding so CustomBindings
        --    already has the latest synced entries)
        EasyWoW_AutoBind(true)
        EasyWoW_RegisterBindings()

        -- 6.1 Apply spell-name-keyed custom bindings (SavedVariables) after RegisterBindings.
        --     Corrects position/order mismatch between C_AssistedCombat and C# JSON rotation.
        EasyWoW_ApplyCustomBindings()

        -- 6. VK lookup — primary: by spell name from C# CustomBindings
        --                    fallback: by position in rotation list
        local vkCode = 0
        local modifiers = 0
        if spellName and spellName ~= "" then
            local key = EasyWoW_CustomBindings[spellName]
            if not key and position > 0 then
                key = EasyWoW_GetKeyForPosition(spellID, position)
            end
            if key then
                vkCode, modifiers = EasyWoW_ParseKey(key)
            end
        end

        -- 7. Write combat state to GP[31] (for auto-stop out of combat)
        GP[31] = UnitAffectingCombat and UnitAffectingCombat("player") and 1 or 0

        -- 8. Cast/Channel detection (unified approach):
        --    Detects ANY cast or channel (interruptible or not) by reading
        --    the spell ID from UnitCastingInfo (position 9) or UnitChannelInfo
        --    (position 8). When any spell is being cast/channeled, clear GP[25-30]
        --    so C# sees idx=0 and doesn't send keys (preventing channel interruption).
        --    GP[32] stores the active cast/channel spell ID for C# diagnostic.
        local castSpellId = 0
        if UnitCastingInfo then
            castSpellId = select(9, UnitCastingInfo("player")) or 0
        end
        if castSpellId == 0 and UnitChannelInfo then
            castSpellId = select(8, UnitChannelInfo("player")) or 0
        end
        GP[32] = castSpellId

        local anyBusy = castSpellId > 0
        if anyBusy then
            GP[25] = 0
            GP[26] = 0
            GP[27] = 0
            GP[28] = 0
            GP[29] = 0
            GP[30] = 0
            spellName = ""
        end

        -- 9. Write action data ONLY when not casting/channeling.
        --     C# sees idx=0 and returns early, preventing channel interruption.
        if not anyBusy then
            GP[25] = (spellID or 0) * 65536 + (position or 0) * 256
            GP[26] = vkCode
            GP[27] = modifiers
        end

        GP[33] = 0  -- clear error flag
    end)

    -- 10a. Report Lua errors via GP[33] so C# client can diagnose.
    --      GP[33] = error code (0 = success, nonzero = failed).
    if not ok then
        GP[33] = 1
    else
        GP[33] = 0
    end

    -- 11. Heartbeat: ALWAYS runs, never blocked by Lua errors or taint.
    --    Uses a distinct range (9e12+) to distinguish from fresh tables.
    heartbeat = heartbeat + 1
    GP[11] = 9000000000000.0 + heartbeat
end)

-- Start OnUpdate after addon loads
local initFrame = CreateFrame("Frame")
initFrame:RegisterEvent("ADDON_LOADED")
initFrame:SetScript("OnEvent", function(_, _, arg1)
    if arg1 ~= "EasyWoW" then return end
    initFrame:UnregisterAllEvents()
    initFrame:Hide()
    updateFrame:Show()
    print("|cff00ff00[EasyWoW]|r 成功载入")
end)

-- Hide until init completes
updateFrame:Hide()

