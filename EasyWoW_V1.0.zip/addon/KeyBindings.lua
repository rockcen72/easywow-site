-- KeyBindings.lua
-- Flat key binding management by position index (no spec dependency).
-- Bindings stored as WoW key strings: "ALT-CTRL-SHIFT-A"
-- External C# client reads VK+modifiers from shared memory.

EasyWoW_Bindings = EasyWoW_Bindings or {}

-- Saved variable: spell-name-keyed custom bindings for /reload survival.
-- C# sync writes to GP[450-456] → ProcessPendingBinding → EasyWoW_CustomBindings[spellName] = key.
-- On /reload, WoW restores this table from disk; ApplyCustomBindings re-registers everything.
EasyWoW_CustomBindings = EasyWoW_CustomBindings or {}
local customBindingsApplied = false

-- WoW key name -> Win32 VK code mapping
local VK = {
    ["0"]=0x30,["1"]=0x31,["2"]=0x32,["3"]=0x33,["4"]=0x34,
    ["5"]=0x35,["6"]=0x36,["7"]=0x37,["8"]=0x38,["9"]=0x39,
    ["A"]=0x41,["B"]=0x42,["C"]=0x43,["D"]=0x44,["E"]=0x45,
    ["F"]=0x46,["G"]=0x47,["H"]=0x48,["I"]=0x49,["J"]=0x4A,
    ["K"]=0x4B,["L"]=0x4C,["M"]=0x4D,["N"]=0x4E,["O"]=0x4F,
    ["P"]=0x50,["Q"]=0x51,["R"]=0x52,["S"]=0x53,["T"]=0x54,
    ["U"]=0x55,["V"]=0x56,["W"]=0x57,["X"]=0x58,["Y"]=0x59,["Z"]=0x5A,
    ["F1"]=0x70,["F2"]=0x71,["F3"]=0x72,["F4"]=0x73,
    ["F5"]=0x74,["F6"]=0x75,["F7"]=0x76,["F8"]=0x77,
    ["F9"]=0x78,["F10"]=0x79,["F11"]=0x7A,["F12"]=0x7B,
    ["F13"]=0x7C,["F14"]=0x7D,["F15"]=0x7E,["F16"]=0x7F,
    ["F17"]=0x80,["F18"]=0x81,["F19"]=0x82,["F20"]=0x83,
    ["F21"]=0x84,["F22"]=0x85,["F23"]=0x86,["F24"]=0x87,
    ["SPACE"]=0x20,["ENTER"]=0x0D,["TAB"]=0x09,
    ["ESCAPE"]=0x1B,["BACKSPACE"]=0x08,
    ["NUMPAD0"]=0x60,["NUMPAD1"]=0x61,["NUMPAD2"]=0x62,
    ["NUMPAD3"]=0x63,["NUMPAD4"]=0x64,["NUMPAD5"]=0x65,
    ["NUMPAD6"]=0x66,["NUMPAD7"]=0x67,["NUMPAD8"]=0x68,["NUMPAD9"]=0x69,
    ["UP"]=0x26,["DOWN"]=0x28,["LEFT"]=0x25,["RIGHT"]=0x27,
    ["HOME"]=0x24,["END"]=0x23,["PAGEUP"]=0x21,["PAGEDOWN"]=0x22,
    ["INSERT"]=0x2D,["DELETE"]=0x2E,
    ["MINUS"]=0xBD,["EQUALS"]=0xBB,
    ["LBRACKET"]=0xDB,["RBRACKET"]=0xDD,
    ["SEMICOLON"]=0xBA,["APOSTROPHE"]=0xDE,
    ["BACKSLASH"]=0xDC,["COMMA"]=0xBC,["PERIOD"]=0xBE,["SLASH"]=0xBF,
}

local MOD_SHIFT = 1
local MOD_CTRL  = 2
local MOD_ALT   = 4

--- Parse "ALT-CTRL-SHIFT-A" -> (vk, modifiers)
function EasyWoW_ParseKey(wowKey)
    if not wowKey or wowKey == "" then return nil, 0 end
    local mod = 0
    local key = wowKey

    local function strip(prefix, flag)
        if key:find("^" .. prefix .. "%-") then
            mod = mod + flag
            key = key:sub(#prefix + 2)
        end
    end
    strip("SHIFT", MOD_SHIFT)
    strip("CTRL", MOD_CTRL)
    strip("ALT", MOD_ALT)
    strip("SHIFT", MOD_SHIFT)
    strip("ALT", MOD_ALT)
    strip("CTRL", MOD_CTRL)
    strip("ALT", MOD_ALT)
    strip("SHIFT", MOD_SHIFT)
    strip("CTRL", MOD_CTRL)

    local vk = VK[key:upper()]
    if not vk then return nil, 0 end
    return vk, mod
end

--- Look up the key for a position (flat binding or fallback).
function EasyWoW_GetKeyForPosition(spellId, position)
    if EasyWoW_Bindings[position] then
        return EasyWoW_Bindings[position]
    end
    local key = GetBindingKey(spellId)
    if key and key ~= "" then return key end
    return nil
end

-- Auto-generate non-conflicting keys: ALT-CTRL-SHIFT-{A..Z,F1..F12}
local function GetAutoKey(position)
    if position <= 26 then
        local letter = string.char(string.byte('A') + position - 1)
        return "ALT-CTRL-SHIFT-" .. letter
    elseif position <= 38 then
        return "ALT-CTRL-SHIFT-F" .. (position - 26)
    end
    return nil
end

--- Generate single-fire F-key: F13-F24 based on position (1→F13, 12→F24).
--- These keys have no default WoW bindings, so C# can send them without
--- modifier key conflicts. Used by FireOneSkill for one-shot casts.
local function GetSingleFireKey(position)
    if position >= 1 and position <= 12 then
        return "F" .. (12 + position)
    end
    return nil
end

--- All 6 modifier-order permutations that WoW treats as the same key.
--- Cache files from previous syncs or other addons may use variant orders
--- (e.g. CTRL-ALT-SHIFT-A instead of ALT-CTRL-SHIFT-A), so all must be cleared.
local MODIFIER_ORDERS = {
    {"ALT", "CTRL", "SHIFT"},
    {"ALT", "SHIFT", "CTRL"},
    {"CTRL", "ALT", "SHIFT"},
    {"CTRL", "SHIFT", "ALT"},
    {"SHIFT", "ALT", "CTRL"},
    {"SHIFT", "CTRL", "ALT"},
}

--- Clear ALL EasyWoW-range bindings from WoW's in-memory binding system,
--- covering all 6 modifier-order variants of {A..Z,0..9,F1..F12}.
--- RegisterBindings handles the file save after re-registering EasyWoW spells.
function ClearAllEasyWowBindings()
    local suffixes = {}
    for i = 0, 25 do
        suffixes[#suffixes+1] = string.char(string.byte('A') + i)
    end
    for i = 1, 12 do
        suffixes[#suffixes+1] = "F" .. i
    end
    for i = 0, 9 do
        suffixes[#suffixes+1] = tostring(i)
    end
    for _, suffix in ipairs(suffixes) do
        for _, mods in ipairs(MODIFIER_ORDERS) do
            pcall(SetBinding, table.concat(mods, "-") .. "-" .. suffix, "")
        end
    end
    -- Clear single-fire F-keys (F13-F24)
    for i = 13, 24 do
        pcall(SetBinding, "F" .. i, "")
    end
end

--- Check if a key is free (not bound to any action in WoW).
function EasyWoW_IsKeyFree(key)
    if not key then return true end
    local existing = C_KeyBindings.GetBindingByKey(key)
    return existing == nil
end

--- Show all bindings.
function EasyWoW_ListBindings()
    local count = 0
    for pos=1, 60 do
        if EasyWoW_Bindings[pos] then
            if count == 0 then
                print("|cff00ff00[EasyWoW]|r 按键绑定:")
            end
            print("  位置 " .. pos .. " -> " .. EasyWoW_Bindings[pos])
            count = count + 1
        end
    end
    if count == 0 then
        print("|cff00ff00[EasyWoW]|r 当前无绑定，输入 /ew auto 自动生成")
    end
end

--- Set a key binding at given position.
function EasyWoW_SetBinding(position, key)
    if position < 1 or position > 60 then
        print("|cffff0000[EasyWoW]|r 位置无效 (1-60)")
        return
    end
    EasyWoW_Bindings[position] = key
end

--- Clear a binding at position.
function EasyWoW_ClearBinding(position)
    EasyWoW_Bindings[position] = nil
    print("|cff00ff00[EasyWoW]|r 已清除位置 " .. position)
end

--- Clear all bindings.
function EasyWoW_ClearAllBindings()
    EasyWoW_Bindings = {}
    EasyWoW_ResetBindings()
    print("|cff00ff00[EasyWoW]|r 已清除全部")
end

--- Register all bindings with WoW's native key system (SetBindingSpell).
--- Iterates EasyWoW_CustomBindings by spell name (C# authoritative source),
--- NOT by rotation list position (which may differ from C# JSON order).
--- Duplicate key detection: if two spells share the same key, only the first
--- one encountered by key iteration is registered (pairs() order is random).
local bindingsRegistered = false
function EasyWoW_RegisterBindings()
    if bindingsRegistered then return end
    if UnitAffectingCombat and UnitAffectingCombat("player") then return end

    -- Auto-fill from rotation list if CustomBindings is empty (first run)
    if not EasyWoW_CustomBindings then EasyWoW_CustomBindings = {} end
    if not next(EasyWoW_CustomBindings) then
        local spells = EasyWoW_GetRotationSpells()
        if spells then
            for i, sid in ipairs(spells) do
                local info = C_Spell and C_Spell.GetSpellInfo(sid)
                if info and info.name then
                    local autoKey = GetAutoKey(i)
                    if autoKey and not EasyWoW_CustomBindings[info.name] then
                        EasyWoW_CustomBindings[info.name] = autoKey
                    end
                end
            end
        end
    end
    if not next(EasyWoW_CustomBindings) then return end

    -- Detect duplicates: build key→spellName map, warn on conflicts.
    -- Only register each key ONCE (first spell wins) to prevent last-wins overwrite.
    local registered = {}
    local ok = 0
    for spellName, key in pairs(EasyWoW_CustomBindings) do
        if key and spellName then
            if registered[key] then
                -- duplicate key, skip silently
            else
                registered[key] = spellName
                -- Only bind keys with modifiers (ALT/CTRL/SHIFT). Plain keys
                -- like "A" or "F1" come from the user's action bar (NDui), not
                -- from auto-generation (which always produces ALT-CTRL-SHIFT-*).
                -- C# sends plain keys via PostMessage → WoW action bar click →
                -- spell casts correctly. SetBinding("A", "") would clear the
                -- action bar binding, which the user doesn't want.
                if key:find("ALT") or key:find("CTRL") or key:find("SHIFT") then
                    local s1, b1 = pcall(SetBinding, key, "")
                    if s1 and b1 then
                        local s2, b2 = pcall(SetBindingSpell, key, spellName)
                        if s2 and b2 then ok = ok + 1 end
                    end
                end
            end
        end
    end
    if ok > 0 then
        -- Register single-fire F-keys (F13-F24) alongside main bindings.
        -- These survive /reload because CustomBindings is saved to disk.
        local spells = EasyWoW_GetRotationSpells()
        if spells then
            for i, sid in ipairs(spells) do
                local info = C_Spell and C_Spell.GetSpellInfo(sid)
                if info and info.name then
                    local sfKey = GetSingleFireKey(i)
                    if sfKey and EasyWoW_CustomBindings[info.name] then
                        pcall(SetBinding, sfKey, "")
                        pcall(SetBindingSpell, sfKey, info.name)
                    end
                end
            end
        end
        bindingsRegistered = true
        pcall(SaveBindings, 2)  -- account-wide, avoid character-specific bindings
    end
end

--- Reset registered flag (call on spec change or binding clear).
function EasyWoW_ResetBindings()
    bindingsRegistered = false
    customBindingsApplied = false
end

--- Apply spell-name-keyed custom bindings from SavedVariables.
--- No rotation list filtering — registers ALL spells from EasyWoW_CustomBindings.
--- Also backfills EasyWoW_Bindings[position] for GetKeyForPosition callers.
function EasyWoW_ApplyCustomBindings()
    if customBindingsApplied then return end

    -- Fallback: populate from rotation list if CustomBindings is empty (first run / /reload)
    if not EasyWoW_CustomBindings then EasyWoW_CustomBindings = {} end
    if not next(EasyWoW_CustomBindings) then
        local spells = EasyWoW_GetRotationSpells()
        if spells then
            for i, sid in ipairs(spells) do
                local info = C_Spell and C_Spell.GetSpellInfo(sid)
                if info and info.name then
                    local autoKey = GetAutoKey(i)
                    if autoKey and not EasyWoW_CustomBindings[info.name] then
                        EasyWoW_CustomBindings[info.name] = autoKey
                    end
                end
            end
        end
    end
    if not next(EasyWoW_CustomBindings) then return end

    -- Apply all custom bindings by spell name (no rotation list filter).
    -- IMPORTANT: skip if RegisterBindings already did this. Both use pairs() which
    -- has random order, and running both independently causes duplicate key conflicts
    -- where the winner in RegisterBindings gets overwritten by ApplyCustomBindings.
    if not bindingsRegistered then
        local inCombat = UnitAffectingCombat and UnitAffectingCombat("player")
        if not inCombat then
            local applied = 0
            local registered = {}
            for spellName, key in pairs(EasyWoW_CustomBindings) do
                if key and spellName then
                    if registered[key] then
                        -- duplicate key, skip silently
                    else
                        registered[key] = spellName
                        -- Modifier-only: skip plain keys to preserve NDui
                        -- action bar bindings. See RegisterBindings above.
                        if key:find("ALT") or key:find("CTRL") or key:find("SHIFT") then
                            local s1, b1 = pcall(SetBinding, key, "")
                            if s1 and b1 then
                                local s2, b2 = pcall(SetBindingSpell, key, spellName)
                                if s2 and b2 then applied = applied + 1 end
                            end
                        end
                    end
                end
            end
            if applied > 0 then
                -- Register single-fire F-keys (F13-F24) — survives /reload.
                local sfSpells = EasyWoW_GetRotationSpells()
                if sfSpells then
                    for i, sid in ipairs(sfSpells) do
                        local info = C_Spell and C_Spell.GetSpellInfo(sid)
                        if info and info.name then
                            local sfKey = GetSingleFireKey(i)
                            if sfKey and EasyWoW_CustomBindings[info.name] then
                                pcall(SetBinding, sfKey, "")
                                pcall(SetBindingSpell, sfKey, info.name)
                            end
                        end
                    end
                end
                pcall(SaveBindings, 2)
            end
        end
    end
    customBindingsApplied = true

    -- Backfill EasyWoW_Bindings[position] — safe, runs even in combat.
    local spells = EasyWoW_GetRotationSpells()
    if spells then
        for i, sid in ipairs(spells) do
            local info = C_Spell and C_Spell.GetSpellInfo(sid)
            if info and info.name then
                local customKey = EasyWoW_CustomBindings[info.name]
                if customKey and not EasyWoW_Bindings[i] then
                    EasyWoW_Bindings[i] = customKey
                end
            end
        end
    end
end
function EasyWoW_AutoBind(silent)
    local spells = EasyWoW_GetRotationSpells()
    if not spells or #spells == 0 then
        if not silent then
            print("|cffff0000[EasyWoW]|r 未获取到当前专精的技能列表")
        end
        return
    end
    local filled = 0
    local conflicts = 0
    for i=1, #spells do
        if not EasyWoW_Bindings[i] then
            local key = GetAutoKey(i)
            if key then
                if EasyWoW_IsKeyFree(key) then
                    EasyWoW_Bindings[i] = key
                    filled = filled + 1
                else
                    conflicts = conflicts + 1
                end
            end
        end
    end
    if not silent then
        print("|cff00ff00[EasyWoW]|r 自动填充 " .. filled .. " 个位置" ..
            (conflicts > 0 and ("，|cffffff00" .. conflicts .. " 个因冲突跳过|r") or ""))
    end
end

-- Slash command
local function HandleSlash(msg)
    local args = {}
    for a in msg:gmatch("%S+") do args[#args+1] = a end

    if #args == 0 then
        print("|cff00ff00[EasyWoW]|r 命令:")
        print("  /ew list              — 显示绑定")
        print("  /ew set <位置> <按键>   — 设置绑定 (例: /ew set 1 ALT-CTRL-SHIFT-A)")
        print("  /ew clear <位置>      — 清除指定位置")
        print("  /ew clearall          — 清除全部")
        print("  /ew auto              — 自动填充 (ALT-CTRL-SHIFT-*)")
        print("  /ew resetpos           — 重置 UI 位置到屏幕中央")
        print("  /ew rotation          — 显示旋转列表")
        print("  /ew bindings          — 显示 WoW 绑定状态")
        return
    end

    local cmd = args[1]:lower()
    if cmd == "list" then
        EasyWoW_ListBindings()
    elseif cmd == "set" then
        if #args < 3 then
            print("|cffff0000[EasyWoW]|r 用法: /ew set <位置> <按键>")
            return
        end
        local pos = tonumber(args[2])
        if not pos then print("|cffff0000[EasyWoW]|r 位置必须为数字"); return end
        EasyWoW_SetBinding(pos, args[3])
    elseif cmd == "clear" then
        if #args < 2 then print("|cffff0000[EasyWoW]|r 用法: /ew clear <位置>"); return end
        local pos = tonumber(args[2])
        if pos then EasyWoW_ClearBinding(pos) end
    elseif cmd == "clearall" then
        EasyWoW_ClearAllBindings()
    elseif cmd == "auto" then
        EasyWoW_AutoBind()
    elseif cmd == "poisons" or cmd == "毒药" then
        local mh, _, _, _, oh = GetWeaponEnchantInfo()
        print("|cFFFFCC00[EasyWoW] 毒药状态|r")
        print("主手附魔: " .. (mh and "|cFF00FF00有|r" or "|cFFFF4444无|r"))
        print("副手附魔: " .. (oh and "|cFF00FF00有|r" or "|cFFFF4444无|r"))
        for i = 1, 120 do
            local t, id = GetActionInfo(i)
            if t == "spell" and id then
                local info = C_Spell.GetSpellInfo(id)
                if info and info.name and (info.name:find("毒药") or info.name:find("Poison")) then
                    print(string.format("动作条 %d: %s (ID=%d)", i, info.name, id))
                end
            end
        end
    elseif cmd == "rotation" or cmd == "列表" then
        local spells = EasyWoW_GetRotationSpells()
        if not spells or #spells == 0 then
            print("|cFFFFCC00[EasyWoW]|r 旋转列表为空")
        else
            print("|cFFFFCC00[EasyWoW]|r 旋转列表 (" .. #spells .. " 个技能):")
            for i, sid in ipairs(spells) do
                local info = C_Spell and C_Spell.GetSpellInfo(sid)
                local name = (info and info.name) or "?"
                print(string.format("  %d. ID=%d %s", i, sid, name))
            end
        end
    elseif cmd == "resetpos" or cmd == "重置位置" then
        EasyWoW_UIPos = nil
        local uiFrame = _G.EasyWoWUIFrame
        if uiFrame then
            uiFrame:ClearAllPoints()
            uiFrame:SetPoint("CENTER", UIParent, "CENTER", 0, -200)
        end
        print("|cff00ff00[EasyWoW]|r 位置已重置到屏幕中央，/reload 后生效")
    elseif cmd == "bindings" or cmd == "绑定" then
        print("|cFFFFCC00[EasyWoW]|r 当前按键绑定:")
        for i = 1, 60 do
            local key = EasyWoW_Bindings[i]
            if key then
                -- Find expected spell by reverse lookup in CustomBindings (C# authoritative source)
                local expectedName = ""
                for sname, k in pairs(EasyWoW_CustomBindings) do
                    if k == key then expectedName = sname; break end
                end
                if expectedName == "" then
                    -- Fallback: rotation list position
                    local spells = EasyWoW_GetRotationSpells()
                    local sid = spells and spells[i]
                    local info = sid and C_Spell.GetSpellInfo(sid)
                    expectedName = (info and info.name) or "?"
                end
                local boundTo = C_KeyBindings.GetBindingByKey(key)
                local bareBinding = boundTo and boundTo:gsub("^SPELL%s+", "")
                local match = (bareBinding == expectedName) and "✓" or "|cFFFF4444✗|r"
                print(string.format("  %d. %s → %s (WoW绑定: %s) %s", i, key, expectedName, boundTo or "无", match))
            end
        end
    else
        print("|cffff0000[EasyWoW]|r 未知命令: " .. cmd)
    end
end

--- Set a key binding to a @cursor macro for ground-targeted spells.
--- Creates a macro "EW_<spellName>" if not exists, then binds the key to it.
--- Falls back to SetBindingSpell if macro creation fails (in combat).
function EasyWoW_SetCursorTargetBinding(key, spellName)
    if not key or not spellName then return false end
    local macroName = "EW_" .. spellName
    local macroIndex = GetMacroIndexByName(macroName)

    if not macroIndex or macroIndex == 0 then
        local ok, idx = pcall(CreateMacro, macroName, 1, "/cast [@cursor] " .. spellName, nil)
        if ok and idx then
            macroIndex = idx
        else
            -- Fallback to regular SetBindingSpell
            return pcall(SetBindingSpell, key, spellName)
        end
    end

    -- Use SetBinding with "MACRO <name>" string instead of SetBindingMacro(index)
    -- SetBindingMacro appears to return true without actually changing the binding
    return pcall(SetBinding, key, "MACRO " .. macroName)
end

--- Process pending binding from external C# client via GP[450-457].
--- GP[449] = clear signal (1.0 = clear all bindings before new sync)
--- GP[450] = slot number (1-60)
--- GP[451-453] = packed key string (6 bytes per double)
--- GP[454-456] = packed spell name (6 bytes per double, UTF-8)
--- GP[457] = cursor target flag (1.0 = use @cursor macro)
function EasyWoW_ProcessPendingBinding()
    -- GP[448] soft clear: clears SavedVariable tables without calling ClearAllEasyWowBindings.
    -- Used by C# silent sync (rotation save) to remove stale entries from previous specs
    -- without the 200ms SetBinding storm that freezes OnUpdate heartbeat.
    local softClear = GP[448]
    if softClear and softClear > 0.5 and softClear < 1000000 then
        for k in pairs(EasyWoW_CustomBindings) do EasyWoW_CustomBindings[k] = nil end
        for k in pairs(EasyWoW_Bindings) do EasyWoW_Bindings[k] = nil end
        customBindingsApplied = false
        bindingsRegistered = false
        GP[448] = 0
        -- Fall through: let GP[450] set new bindings in the same frame
    end

    -- Check clear signal first (written by C# before rotation switch/delete).
    -- Clears SavedVariable tables in-place to preserve table references.
    local clearFlag = GP[449]
    if clearFlag and clearFlag > 0.5 and clearFlag < 1000000 then
        -- Thorough clear: remove ALL EasyWoW-range bindings from WoW (A-Z, 0-9, F1-F12)
        -- Saves to character default binding set (shared across all specs).
        -- This prevents stale bindings from previous specs/sessions accumulating
        -- in bindings-cache.wtf and conflicting with current bindings.
        ClearAllEasyWowBindings()
        -- Clear SavedVariable tables
        for k in pairs(EasyWoW_CustomBindings) do EasyWoW_CustomBindings[k] = nil end
        for k in pairs(EasyWoW_Bindings) do EasyWoW_Bindings[k] = nil end
        customBindingsApplied = false
        bindingsRegistered = false
        GP[449] = 0
        -- Fall through: let GP[450] processing set new bindings in the same frame
    end

    local slot = GP[450]
    if not slot or slot <= 0 or slot > 60 then return end

    -- Helper: decode packed string from 3 doubles
    local function decodePacked(base)
        local result = ""
        for di = 0, 2 do
            local val = GP[base + di]
            if val and val > 0 then
                local bits = math.floor(val + 0.5)
                if bits <= 0 then break end
                for ci = 0, 5 do
                    local byte = math.floor(bits / (256 ^ ci)) % 256
                    if byte == 0 then break end
                    result = result .. string.char(byte)
                end
            end
        end
        return result
    end

    local key = decodePacked(451)
    local spellName = decodePacked(454)
    local isCursorTarget = (GP[457] or 0) > 0.5 and (GP[457] or 0) < 1000000

    -- Normalize key to WoW format: "Ctrl+Alt+Shift+H" → "ALT-CTRL-SHIFT-H"
    if key then
        key = string.upper(key)
        key = string.gsub(key, "+", "-")
    end

    -- Re-verify GP[450] hasn't changed while we were decoding.
    -- Prevents processing stale/mismatched data if C# wrote a new slot mid-read.
    if GP[450] ~= slot then return end

    if key ~= "" and spellName ~= "" then
        EasyWoW_SetBinding(slot, key)
        -- Always save to spell-name-keyed table (not protected)
        EasyWoW_CustomBindings[spellName] = key
        customBindingsApplied = false
        bindingsRegistered = false

        -- Cursor target: create @cursor macro (only path that needs SetBinding)
        local inCombat = UnitAffectingCombat and UnitAffectingCombat("player")
        if not inCombat and isCursorTarget then
            if EasyWoW_SetCursorTargetBinding(key, spellName) then
                pcall(SaveBindings, 2)
            end
        end

        -- Register single-fire F-key binding (F13-F24) alongside the main binding.
        -- C# FireOneSkill sends just this single F-key (no modifiers) to avoid
        -- conflicts with WoW's default key bindings. Only set out of combat since
        -- SetBindingSpell is protected in combat — sync already defers to out-of-combat.
        if not inCombat then
            local sfKey = GetSingleFireKey(slot)
            if sfKey then
                pcall(SetBinding, sfKey, "")
                pcall(SetBindingSpell, sfKey, spellName)
            end
        end

        -- Note: RegisterBindings applies all custom bindings by spell name,
        -- so new synced bindings are applied on the next OnUpdate.
    elseif key ~= "" then
        -- Fallback: only key available
        EasyWoW_SetBinding(slot, key)
        EasyWoW_ResetBindings()
    end

    GP[450] = 0  -- clear pending flag
end

SLASH_EASYWOW1 = "/easywow"
SLASH_EASYWOW2 = "/ew"
SlashCmdList["EASYWOW"] = HandleSlash
