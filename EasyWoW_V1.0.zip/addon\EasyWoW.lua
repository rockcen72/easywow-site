-- EasyWoW.lua
-- Creates GP[] bridge table with magic pattern for process memory scanning.
-- On each frame: reads recommended spell, finds position, looks up key binding,
-- writes action data to GP[25]/GP[26]/GP[27].

local magic = 202600000001.0

-- Create GP[]: 999 entries, each = magic + (index - 1)
-- Lua 5.1 stores the array part as a contiguous TValue block, which the
-- hook DLL's memory scanner locates via the magic number pattern.
GP = {}
for i = 1, 999 do
    GP[i] = magic + (i - 1)
end

-- Simple load test
local _, _, _, _, class = UnitClass("player")
DEFAULT_CHAT_FRAME:AddMessage("|cFFFFCC00[EasyWoW]|r load OK |cFF888888(class=" .. (class or "?") .. ")|r")

-- Scan action bar for spell IDs currently available on it.
-- This is the "reality check": if a spell isn't on the bar, it can't be cast
-- (e.g. transformation abilities like 哀恸箭 when 狂野怒火 isn't active).
local function ScanActionBarSpells()
    local barSpells = {}
    local prefixes = {
        "ActionButton", "MultiBarBottomLeftButton", "MultiBarBottomRightButton",
        "MultiBarRightButton", "MultiBarLeftButton",
        "MultiBar5Button", "MultiBar6Button", "MultiBar7Button",
    }
    for _, prefix in ipairs(prefixes) do
        for i = 1, 12 do
            local btn = _G[prefix .. i]
            if btn then
                local slot = btn.action or (btn.GetAttribute and btn:GetAttribute("action"))
                if slot then
                    local actionType, id = GetActionInfo(slot)
                    if actionType == "spell" and id then
                        barSpells[id] = true
                    end
                end
            end
        end
    end
    return barSpells
end

-- Check if a spell is a weapon coating (rogue poison) by name pattern.
-- Works whether the locale is Chinese (毒药) or English (Poison).
function IsWeaponCoating(name)
    if not name then return false end
    -- Chinese: 毒药, English: Poison
    return name:find("毒药") or name:find("药膏") or name:find("Poison")
end

-- Check if target already has a debuff matching this spell's name.
-- Prevents repeatedly applying long-duration debuffs (e.g. rogue poisons).
local function HasActiveAura(sid)
    local info = C_Spell and C_Spell.GetSpellInfo(sid)
    -- Check weapon enchant for rogue poisons (GetWeaponEnchantInfo detects weapon coatings)
    if info and info.name and IsWeaponCoating(info.name) then
        -- Check both main-hand and off-hand for weapon enchant
        local hasMH, _, _, _, hasOH = GetWeaponEnchantInfo()
        if hasMH or hasOH then return true end
    end
    -- Check player buff (e.g. long-duration self-buffs)
    if info and info.name then
        local ok1, _, _, _, _, _, _, _, _, _, spellId = pcall(UnitAura, "player", info.name)
        if ok1 and spellId then return true end
        local ok2, _, _, _, _, _, _, _, _, _, spellId = pcall(UnitAura, "target", info.name)
        if ok2 and spellId then return true end
    end
    return false
end

-- Check if a spell is currently usable (not on cooldown, enough resources).
-- Uses pcall for each check to avoid taint (secret numbers).
local function IsCastable(sid)
    local ok1, usable = pcall(C_Spell.IsSpellUsable, sid)
    if ok1 and not usable then return false end

    local ok2, cdInfo = pcall(C_Spell.GetSpellCooldown, sid)
    if ok2 and cdInfo then
        local ok3, hasCd = pcall(function() return cdInfo.duration and cdInfo.duration > 0 end)
        if ok3 and hasCd then return false end
    end

    return true
end

-- Find the best spell to cast using JustAC-style approach:
-- 1. Scan action bar (only spells actually available on it)
-- 2. Cross-reference with rotation list (priority ordering)
-- 3. C_AssistedCombat recommendation is the single source of truth when valid.
--    Unlike JustAC's original design, we DO NOT second-guess C_AssistedCombat
--    with rotation-list fallback — that caused rogue poisons to keep re-applying
--    since C_AssistedCombat correctly avoids them but the fallback re-selected them.
local function FindCastableSpell(recommended)
    local barSpells = ScanActionBarSpells()
    local spells = EasyWoW_GetRotationSpells()

    -- No rotation list: pick any castable spell from the action bar
    -- Skip weapon coatings since unit aura / weapon enchant checks are unreliable.
    if not spells or #spells == 0 then
        for sid in pairs(barSpells) do
            if IsCastable(sid) and not HasActiveAura(sid) then
                local info = C_Spell and C_Spell.GetSpellInfo(sid)
                if not (info and info.name and IsWeaponCoating(info.name)) then
                    return sid
                end
            end
        end
        return nil
    end

    -- C_AssistedCombat provides a valid, castable recommendation → trust it unconditionally.
    -- No HasActiveAura check: C_AssistedCombat handles state tracking internally,
    -- including which weapon coatings to apply and when (rogue needs up to 4 coatings).
    if recommended and recommended > 0 and IsCastable(recommended) then
        return recommended
    end

    -- C_AssistedCombat returned nil or spell not usable → fallback to rotation list.
    -- Skip coatings: they should only be applied when C_AssistedCombat explicitly
    -- recommends them (handled above). Without this filter, coatings get selected
    -- whenever non-coating skills are on cooldown, causing unnecessary re-applies.
    for _, sid in ipairs(spells) do
        if IsCastable(sid) and not HasActiveAura(sid) then
            local info = C_Spell and C_Spell.GetSpellInfo(sid)
            if not (info and info.name and IsWeaponCoating(info.name)) then
                return sid
            end
        end
    end
    return nil
end

-- Heartbeat counter
local heartbeat = 0
local lastErrorReported = false

-- Main OnUpdate frame (started after ADDON_LOADED)
local updateFrame = CreateFrame("Frame")

updateFrame:SetScript("OnUpdate", function()
    -- Wrap in pcall + report errors to GP[33] for C# diagnostic.
    local ok, err = pcall(function()
        -- 1. Get recommended spell from C_AssistedCombat
        local recommended = nil
        if C_AssistedCombat and C_AssistedCombat.GetNextCastSpell then
            local ok2, result = pcall(C_AssistedCombat.GetNextCastSpell)
            if ok2 and result and type(result) == "number" and result > 0 then
                recommended = result
            end
        end

        -- 2. Find castable spell (prefer recommended, fallback to rotation list)
        local spellID = FindCastableSpell(recommended)

        -- 3. Find position in rotation list
        local position = 0
        if spellID then
            local spells = EasyWoW_GetRotationSpells()
            if spells then
                for i, sid in ipairs(spells) do
                    if sid == spellID then
                        position = i
                        break
                    end
                end
            end
        end

        -- 4. Get spell name (BEFORE RegisterBindings to avoid taint)
        local spellName = ""
        if spellID then
            local info = C_Spell and C_Spell.GetSpellInfo(spellID)
            if info and info.name then
                spellName = info.name
            end
        end

        -- 4. Pack spell name into GP[28-30] (6 chars per double, up to 18 chars)
        local b1 = string.byte(spellName, 1) or 0
        local b2 = string.byte(spellName, 2) or 0
        local b3 = string.byte(spellName, 3) or 0
        local b4 = string.byte(spellName, 4) or 0
        local b5 = string.byte(spellName, 5) or 0
        local b6 = string.byte(spellName, 6) or 0
        GP[28] = b1 + b2*256 + b3*65536 + b4*16777216 + b5*4294967296 + b6*1099511627776

        local b7  = string.byte(spellName, 7) or 0
        local b8  = string.byte(spellName, 8) or 0
        local b9  = string.byte(spellName, 9) or 0
        local b10 = string.byte(spellName, 10) or 0
        local b11 = string.byte(spellName, 11) or 0
        local b12 = string.byte(spellName, 12) or 0
        GP[29] = b7 + b8*256 + b9*65536 + b10*16777216 + b11*4294967296 + b12*1099511627776
        GP[30] = 0

        -- 5. AutoBind + Register
        EasyWoW_AutoBind(true)
        EasyWoW_RegisterBindings()

        -- 5.1 Apply spell-name-keyed custom bindings (SavedVariables) after RegisterBindings.
        --     Corrects position/order mismatch between C_AssistedCombat and C# JSON rotation.
        EasyWoW_ApplyCustomBindings()

        -- 6. VK lookup
        local vkCode = 0
        local modifiers = 0
        if position > 0 then
            local key = EasyWoW_GetKeyForPosition(spellID, position)
            if key then
                vkCode, modifiers = EasyWoW_ParseKey(key)
            end
        end

        -- 7. Write combat state to GP[31] (for auto-stop out of combat)
        GP[31] = UnitAffectingCombat and UnitAffectingCombat("player") and 1 or 0

        -- 8. Cast/Channel detection (unified approach):
        --    Detects ANY cast or channel (interruptible or not) by reading
        --    the spell ID from UnitCastingInfo (position 9) or UnitChannelInfo
        --    (position 8). When any spell is being cast/channeled, clear GP[25-30]
        --    so C# sees idx=0 and doesn't send keys (preventing channel interruption).
        --    GP[32] stores the active cast/channel spell ID for C# diagnostic.
        local castSpellId = 0
        if UnitCastingInfo then
            castSpellId = select(9, UnitCastingInfo("player")) or 0
        end
        if castSpellId == 0 and UnitChannelInfo then
            castSpellId = select(8, UnitChannelInfo("player")) or 0
        end
        GP[32] = castSpellId

        local anyBusy = castSpellId > 0
        if anyBusy then
            GP[25] = 0
            GP[26] = 0
            GP[27] = 0
            GP[28] = 0
            GP[29] = 0
            GP[30] = 0
            spellName = ""
        end

        -- 9. Write action data ONLY when not casting/channeling.
        --     C# sees idx=0 and returns early, preventing channel interruption.
        if not anyBusy then
            GP[25] = (spellID or 0) * 65536 + (position or 0) * 256
            GP[26] = vkCode
            GP[27] = modifiers
        end

        -- 10. Process pending binding from C# client (via GP[450-453])
        EasyWoW_ProcessPendingBinding()

        GP[33] = 0  -- clear error flag
    end)

    -- 10a. Report Lua errors via GP[33] so C# client can diagnose.
    --      GP[33] = error code (0 = success, nonzero = failed).
    if not ok then
        GP[33] = 1
        if not lastErrorReported then
            lastErrorReported = true
            geterrorhandler()(err)
        end
    else
        lastErrorReported = false
    end

    -- 11. Heartbeat: ALWAYS runs, never blocked by Lua errors or taint.
    --    Uses a distinct range (9e12+) to distinguish from fresh tables.
    heartbeat = heartbeat + 1
    GP[11] = 9000000000000.0 + heartbeat
end)

-- Start OnUpdate after addon loads
local initFrame = CreateFrame("Frame")
initFrame:RegisterEvent("ADDON_LOADED")
initFrame:SetScript("OnEvent", function(_, _, arg1)
    if arg1 ~= "EasyWoW" then return end
    initFrame:UnregisterAllEvents()
    initFrame:Hide()
    updateFrame:Show()
end)

-- Hide until init completes
updateFrame:Hide()

